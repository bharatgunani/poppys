var config = {
    map: {
        '*': {
            GiftrNewItem: 'Mirasvit_Giftr/js/item/new'
        }
    }
}