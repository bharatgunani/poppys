var config = {
    map: {
        '*': {
            giftr: 'Mirasvit_Giftr/js/giftr',
            giftrItem: 'Mirasvit_Giftr/js/item'
        }
    }
};
